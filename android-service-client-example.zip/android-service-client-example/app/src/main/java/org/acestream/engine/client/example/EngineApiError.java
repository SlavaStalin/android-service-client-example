package org.acestream.engine.client.example;

public class EngineApiError {
    public int code;
    public String message;
}
