package org.acestream.engine.client.example;

public class EngineSessionResponse<T> {
    public EngineSession response;
    public String error;
}
