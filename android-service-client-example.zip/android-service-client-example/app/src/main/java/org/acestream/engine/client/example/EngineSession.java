package org.acestream.engine.client.example;

public class EngineSession {
    public int is_encrypted;
    public int is_live;
    public String infohash;
    public String playback_url;
    public String command_url;
    public String stat_url;
    public String playback_session_id;
}
