package org.acestream.engine.client.example;

public class EngineApiResponse<T> {
    public T result;
    public EngineApiError error;
}
